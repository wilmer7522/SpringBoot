package com.wilmer.prueba.infraestructure.repository;

/*import java.util.List;

import org.springframework.stereotype.Service;

import com.wilmer.prueba.aplication.service.PersonService;
import com.wilmer.prueba.domain.Person;

@Service
public class PersonServicePImpl implements PersonService {


    @Override
    public List<Person> findAllbyFilter(String filter, String value){
        return List.of(new Person(1L, "Alexander" , "Fuentes" , "React"));
    }
}*/
