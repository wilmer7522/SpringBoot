package com.wilmer.prueba.aplication.service;

import java.util.List;

import com.wilmer.prueba.domain.Project;

public interface ProjectService {

    List<Project> findAllProjects();
}
